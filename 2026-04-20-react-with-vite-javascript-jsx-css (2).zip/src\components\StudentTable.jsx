import StudentRow from './StudentRow'

function StudentTable({ students, onScoreChange }) {
  return (
    <section className="panel">
      <div className="panel-header">
        <span className="panel-title">Student Records</span>
        <span className="panel-meta">{students.length} entries</span>
      </div>
      <div className="table-wrapper">
        <table className="student-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Score</th>
              <th>Status</th>
              <th>Update</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student) => (
              <StudentRow
                key={student.id}
                student={student}
                onScoreChange={onScoreChange}
              />
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}

export default StudentTable
