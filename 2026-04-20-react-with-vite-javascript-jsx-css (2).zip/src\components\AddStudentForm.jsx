import { useState } from 'react'

function AddStudentForm({ onAddStudent }) {
  const [name, setName] = useState('')
  const [score, setScore] = useState('')

  const handleSubmit = (event) => {
    event.preventDefault()

    const trimmedName = name.trim()
    const numericScore = Number(score)

    if (!trimmedName || Number.isNaN(numericScore)) {
      return
    }

    const boundedScore = Math.max(0, Math.min(100, numericScore))
    onAddStudent(trimmedName, boundedScore)

    setName('')
    setScore('')
  }

  return (
    <section className="panel">
      <div className="panel-header">
        <span className="panel-title">Register Student</span>
        <span className="panel-meta">New Entry</span>
      </div>
      <form className="student-form" onSubmit={handleSubmit}>
        <div className="input-group">
          <label htmlFor="student-name">Student Name</label>
          <input
            id="student-name"
            type="text"
            placeholder="Student name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            required
          />
        </div>

        <div className="input-group">
          <label htmlFor="student-score">Score (0-100)</label>
          <input
            id="student-score"
            type="number"
            min="0"
            max="100"
            placeholder="Score"
            value={score}
            onChange={(event) => setScore(event.target.value)}
            required
          />
        </div>

        <button type="submit" className="btn-add-student">
          + Add
        </button>
      </form>
    </section>
  )
}

export default AddStudentForm
