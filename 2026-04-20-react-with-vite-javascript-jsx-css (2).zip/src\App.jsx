import { useState } from 'react'
import Header from './components/Header'
import StudentTable from './components/StudentTable'
import AddStudentForm from './components/AddStudentForm'
import './App.css'

const initialStudents = [
  { id: 1, name: 'Aarav', score: 78 },
  { id: 2, name: 'Diya', score: 35 },
  { id: 3, name: 'Kabir', score: 48 },
]

function App() {
  const [students, setStudents] = useState(initialStudents)

  const updateStudentScore = (id, nextScore) => {
    setStudents((prevStudents) =>
      prevStudents.map((student) =>
        student.id === id ? { ...student, score: nextScore } : student,
      ),
    )
  }

  const addStudent = (name, score) => {
    const newStudent = {
      id: Date.now(),
      name,
      score,
    }

    setStudents((prevStudents) => [...prevStudents, newStudent])
  }

  const passedCount = students.filter((student) => student.score >= 40).length
  const averageScore =
    students.length === 0
      ? 0
      : Math.round(
          students.reduce((sum, student) => sum + student.score, 0) /
            students.length,
        )

  return (
    <main className="app-container">
      <Header />
      <AddStudentForm onAddStudent={addStudent} />
      <section className="stats-grid">
        <article className="stat-card">
          <p className="stat-label">Total</p>
          <p className="stat-value">{students.length}</p>
        </article>
        <article className="stat-card">
          <p className="stat-label">Passed</p>
          <p className="stat-value">{passedCount}</p>
        </article>
        <article className="stat-card">
          <p className="stat-label">Avg Score</p>
          <p className="stat-value">{averageScore}</p>
        </article>
      </section>
      <StudentTable students={students} onScoreChange={updateStudentScore} />
    </main>
  )
}

export default App
