function Header() {
  return (
    <header className="app-header">
      <p className="terminal-tag">Academic Registry Console v1.0</p>
      <h1 className="app-title">
        Student <span>Scoreboard</span>
      </h1>
    </header>
  )
}

export default Header
