import { useEffect, useState } from 'react'

function StudentRow({ student, onScoreChange }) {
  const { id, name, score } = student
  const [draftScore, setDraftScore] = useState(String(score))
  const isPassed = score >= 40

  useEffect(() => {
    setDraftScore(String(score))
  }, [score])

  const handleSave = () => {
    const value = Number(draftScore)
    if (Number.isNaN(value)) {
      return
    }

    const boundedScore = Math.max(0, Math.min(100, value))
    onScoreChange(id, boundedScore)
  }

  return (
    <tr>
      <td>{name}</td>
      <td className="score-highlight">{score}</td>
      <td className={isPassed ? 'status-pass' : 'status-fail'}>
        <span className="status-pill">{isPassed ? 'Pass' : 'Fail'}</span>
      </td>
      <td>
        <div className="update-cell">
          <input
            className="score-input"
            type="number"
            min="0"
            max="100"
            value={draftScore}
            onChange={(event) => setDraftScore(event.target.value)}
          />
          <button className="btn-save" type="button" onClick={handleSave}>
            Save
          </button>
        </div>
      </td>
    </tr>
  )
}

export default StudentRow
